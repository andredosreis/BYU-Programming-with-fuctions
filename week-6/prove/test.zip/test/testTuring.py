import random


def main(grammatical_number, tense):

    article = get_determiner(grammatical_number)
    noun = get_noun(grammatical_number)
    verb = get_verb(grammatical_number, tense)

    return print(article+" "+noun+" "+verb)

def get_determiner(grammatical_number):

    if grammatical_number == 1:
        words = ["the", "one"]
    else:
        words = ["some", "many"]

    word = random.choice(words)

    return word

def get_noun(grammatical_number):

    if grammatical_number == 1:
        words = ["adult", "bird", "boy", "car", "cat",
        "child", "dog", "girl", "man", "woman"]
    else:
        words = ["adults", "birds", "boys", "cars", "cats",
        "children", "dogs", "girls", "men", "women"]

    word = random.choice(words)

    return word

def get_verb(grammatical_number, tense):

    if tense == "past":
        verbs = [ "drank", "ate", "grew", "laughed", "thought",
        "ran", "slept", "talked", "walked", "wrote"]
    elif tense == 'present' and grammatical_number != 1:
        verbs = [ "drinks", "eats", "grows", "laughs", "thinks",
        "runs", "sleeps", "talks", "walks", "writes"]
    elif tense == 'present' and grammatical_number == 1:
        verbs = ["drink", "eat", "grow", "laugh", "think",
        "run", "sleep", "talk", "walk", "write"]
    elif tense == 'future':
        verbs = ["will drink", "will eat", "will grow", "will laugh",
        "will think", "will run", "will sleep", "will talk",
        "will walk", "will write"]

    verb = random.choice(verbs)

    return verb

#a.	single	past
main(1, "past")
#b.	plural	past
main(0, "past")
#c.	single	present
main(1, "present")
#d.	plural	present
main(0, "present")
#e.	single	future
main(1, "future")
#f.	plural	future
main(0, "future")
